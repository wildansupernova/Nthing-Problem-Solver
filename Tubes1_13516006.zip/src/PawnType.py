class PawnType:
    QUEEN = "QUEEN"
    BISHOP = "BISHOP"
    ROOK = "ROOK"
    KNIGHT = "KNIGHT"
    EMPTY = "EMPTY"
    WHITE = "WHITE"
    BLACK = "BLACK"


